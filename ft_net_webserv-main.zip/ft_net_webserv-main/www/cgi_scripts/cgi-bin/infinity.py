
from time import sleep

while True:
	sleep(1)