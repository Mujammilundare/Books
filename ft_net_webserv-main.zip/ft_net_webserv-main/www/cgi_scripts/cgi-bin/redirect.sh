#/bin/bash

echo -en "Location: http://youtube.com/results?search_query=not+found\r\n"
echo -en "\r\n"

